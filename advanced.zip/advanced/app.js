/* ENUNT
Modifica fisierul astfel:
- creeaza o variabila in care vom pune valoarea din input (cu document.getElementById)
- in functie verificam cu ajutorul unui if daca numarul este mai mare decat 10
- daca este mai mare decat 10 vom afisa un alert cu textul "Numarul este mai mare decat 10!"
- daca este mai mic decat 10 vom afisa un alert cu textul "Numarul este mai mic decat 10!" 

ATENTIE! In if, cand vom verifica daca variabila este mai mica sau mai mare, nu uitati sa-i puneti .value!

BONUS: Verificati daca input-ul este gol si in acest caz afisati prin alert mesajul "Intai trebui sa introduci un numar!"
*/

function myFunction() {
    alert("Buna!\nCe mai faci?");

  }